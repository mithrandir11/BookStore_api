<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\PaymentSuccessful' => 
    array (
      0 => 'App\\Listeners\\UpdateDiscountUsage@handle',
    ),
  ),
);