<?php

namespace App\Repositories\Interfaces;

interface IPublisherRepository
{
    public function getAllPublishers();
}