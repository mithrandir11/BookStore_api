<?php

return [
    'priority' => [
        'high' => 'بالا',
        'medium' => 'متوسط',
        'low' => 'پایین',
    ],

    'status' => [
        'in_progress' => 'در حال انجام',
        'completed' => 'کامل شده',
        'deferred' => 'به تعویق افتاده',
    ],
];
