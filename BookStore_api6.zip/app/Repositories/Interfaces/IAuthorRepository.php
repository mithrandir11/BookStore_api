<?php

namespace App\Repositories\Interfaces;

interface IAuthorRepository
{
    public function getAllAuthors();
}